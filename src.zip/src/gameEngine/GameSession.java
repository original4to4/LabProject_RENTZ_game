package gameEngine;

import user.InGamePlayer;
import user.Player;
import cards.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * GameSession (aligned to your project's Hand/Deck APIs)
 * - No AI support
 * - Empty constructor for server-created waiting sessions
 * - Uses DeckOfCards.shuffleDeck(), DeckOfCards.drawCard()
 * - Uses Hand.hand clear/getCards via Hand.clear() and getCards()
 * - Listener callbacks call zero-arg onGameStarted() (matching your project)
 */
public class GameSession {
    private int sessionId;
    private GameType selectedGame;
    private ArrayList<InGamePlayer> players;
    private int currentPlayerIndex;
    private ArrayList<Card> currentRound;
    private char leadingSuit;
    private boolean gameStarted;
    private InGamePlayer roundWinner;
    private DeckOfCards deck;
    private int playerNumber;
    private int roundsPlayed;
    private int totalRounds;
    private Map<InGamePlayer, Integer> scores;
    private boolean roundInProgress;
    private List<GameSessionListener> listeners;
    private boolean gameCompleted;
    private InGamePlayer gameWinner;
    private Map<String, Boolean> playerReadyStatus;
    private boolean isNetworkGame;

    // --- Constructors ---

    public GameSession(ArrayList<Player> players) {
        if (players == null || players.size() < 2 || players.size() > 6) {
            throw new IllegalArgumentException("Number of players must be between 2 and 6");
        }

        for (Player player : players) {
            if (player.getName() == null || player.getName().trim().isEmpty()) {
                throw new IllegalArgumentException("All players must have valid names");
            }
        }

        this.players = new ArrayList<>();
        for (Player player : players) {
            InGamePlayer inGamePlayer = new InGamePlayer(player);
            this.players.add(inGamePlayer);
        }

        this.playerNumber = this.players.size();
        this.deck = new DeckOfCards(playerNumber);
        initCommon();
    }

    /**
     * Empty constructor for server-created waiting sessions.
     */
    public GameSession() {
        this.players = new ArrayList<>();
        this.playerNumber = 0;
        this.deck = null;
        initCommon();
    }

    private void initCommon() {
        this.currentRound = new ArrayList<>();
        this.scores = new HashMap<>();
        this.listeners = new CopyOnWriteArrayList<>();
        this.totalRounds = 8;
        this.playerReadyStatus = new HashMap<>();
        this.isNetworkGame = false;
        this.currentPlayerIndex = 0;
        this.leadingSuit = 0;
        this.gameStarted = false;
        this.roundInProgress = false;
        this.gameCompleted = false;
        this.roundsPlayed = 0;

        for (InGamePlayer igp : this.players) {
            scores.put(igp, 0);
            playerReadyStatus.put(igp.getPlayer().getName(), false);
        }
    }

    // --- Meta ---
    public int getSessionId() { return sessionId; }
    public void setSessionId(int sessionId) { this.sessionId = sessionId; }

    public GameType getSelectedGame() { return selectedGame; }
    public void setSelectedGame(GameType selectedGame) { this.selectedGame = selectedGame; }

    public boolean isNetworkGame() { return isNetworkGame; }
    public void setNetworkGame(boolean networkGame) { isNetworkGame = networkGame; }

    public List<InGamePlayer> getPlayers() { return Collections.unmodifiableList(players); }

    // --- Player management ---

    public synchronized boolean addPlayer(Player player) {
        if (player == null) return false;
        if (players.size() >= 6) {
            System.out.println("Cannot add player - maximum players reached");
            return false;
        }
        for (InGamePlayer p : players) {
            if (p.getPlayer().getName().equals(player.getName())) {
                System.out.println("Player already exists in session: " + player.getName());
                return false;
            }
        }

        InGamePlayer newPlayer = new InGamePlayer(player);
        players.add(newPlayer);
        scores.put(newPlayer, 0);
        playerReadyStatus.put(player.getName(), false);

        this.playerNumber = players.size();
        if (!gameStarted) this.deck = new DeckOfCards(playerNumber);

        System.out.println("Added player to session: " + player.getName());
        return true;
    }

    public synchronized boolean removePlayerByName(String playerName) {
        Iterator<InGamePlayer> it = players.iterator();
        boolean removed = false;
        while (it.hasNext()) {
            InGamePlayer igp = it.next();
            if (igp.getPlayer().getName().equals(playerName)) {
                it.remove();
                scores.remove(igp);
                playerReadyStatus.remove(playerName);
                removed = true;
                break;
            }
        }
        if (removed) {
            this.playerNumber = players.size();
            this.deck = playerNumber > 0 ? new DeckOfCards(playerNumber) : null;
        }
        return removed;
    }

    public InGamePlayer getPlayerByName(String name) {
        for (InGamePlayer igp : players) {
            if (igp.getPlayer().getName().equals(name)) return igp;
        }
        return null;
    }

    // --- Ready tracking ---
    public synchronized void setPlayerReady(String playerName, boolean ready) {
        if (!playerReadyStatus.containsKey(playerName)) {
            System.out.println("Attempt to set ready for unknown player: " + playerName);
            return;
        }
        playerReadyStatus.put(playerName, ready);
    }

    public synchronized boolean areAllJoinedPlayersReady() {
        if (players.isEmpty()) return false;
        for (InGamePlayer igp : players) {
            Boolean r = playerReadyStatus.get(igp.getPlayer().getName());
            if (r == null || !r) return false;
        }
        return true;
    }

    // --- Game lifecycle ---
    public synchronized boolean startGame() {
        if (gameStarted) return false;
        if (players.size() < 2) {
            System.out.println("Cannot start game: not enough players");
            return false;
        }

        this.gameStarted = true;
        this.roundsPlayed = 0;
        this.currentPlayerIndex = 0;
        this.totalRounds = 8;

        this.deck = new DeckOfCards(players.size());
        this.deck.shuffleDeck();

        for (InGamePlayer igp : players) {
            if (igp.getHand() == null) igp.setHand(new Hand());
            igp.getHand().clear();
            igp.getTakenCards().clear();
        }

        for (int r = 0; r < totalRounds; r++) {
            for (InGamePlayer igp : players) {
                Card c = deck.drawCard();
                if (c != null) igp.getHand().addCard(c);
            }
        }

        scores.clear();
        for (InGamePlayer igp : players) scores.put(igp, 0);

        notifyGameStarted();
        System.out.println("GameSession " + sessionId + " started with " + players.size() + " players");
        return true;
    }

    public boolean isGameStarted() { return gameStarted; }

    // --- Listener notifications ---
    public void addListener(GameSessionListener l) {
        if (l != null) listeners.add(l);
    }

    public void removeListener(GameSessionListener l) {
        listeners.remove(l);
    }

    private void notifyGameStarted() {
        for (GameSessionListener l : listeners) {
            try { l.onGameStarted(); } catch (Exception ignored) {}
        }
    }

    private void notifyCardPlayed(Card c) {
        for (GameSessionListener l : listeners) {
            try { l.onCardPlayed(c); } catch (Exception ignored) {}
        }
    }

    // --- Helpers used by server ---
    public Map<String, Integer> getScoresAsMap() {
        Map<String, Integer> map = new HashMap<>();
        for (Map.Entry<InGamePlayer, Integer> e : scores.entrySet()) {
            map.put(e.getKey().getPlayer().getName(), e.getValue());
        }
        return map;
    }

    public Map<String, Boolean> getPlayerReadyStatus() {
        return Collections.unmodifiableMap(playerReadyStatus);
    }
}
