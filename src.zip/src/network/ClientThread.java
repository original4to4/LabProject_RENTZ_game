package network;

import user.Player;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class ClientThread extends Thread {
    private final Socket socket;
    private final String clientId;
    private final GameServer server;
    private ObjectOutputStream output;
    private ObjectInputStream input;
    private boolean connected = true;
    private String playerName;

    public ClientThread(Socket socket, String clientId, GameServer server) {
        this.socket = socket;
        this.clientId = clientId;
        this.server = server;
    }

    @Override
    public void run() {
        try {
            output = new ObjectOutputStream(socket.getOutputStream());
            input = new ObjectInputStream(socket.getInputStream());

            // Send welcome message with client ID
            sendMessage(new GameMessage("WELCOME", "SERVER", clientId));

            // Send current session list
            sendSessionList();

            // Listen for messages from client
            while (connected) {
                try {
                    Object obj = input.readObject();
                    if (obj instanceof GameMessage) {
                        handleMessage((GameMessage) obj);
                    }
                } catch (EOFException e) {
                    break; // Client disconnected
                } catch (ClassNotFoundException e) {
                    System.err.println("Invalid message from client " + clientId);
                }
            }

        } catch (IOException e) {
            System.err.println("Client connection error: " + e.getMessage());
        } finally {
            disconnect();
        }
    }

    private void handleMessage(GameMessage message) {
        System.out.println("📨 From " + message.getSender() + ": " + message.getType());

        try {
            switch (message.getType()) {
                case GameMessage.PLAYER_JOIN:
                    handlePlayerJoin(message);
                    break;

                case GameMessage.JOIN_SESSION:
                    handleJoinSession(message);
                    break;

                case GameMessage.CREATE_SESSION:
                    handleCreateSession(message);
                    break;

                case GameMessage.START_GAME:
                    handleStartGame(message);
                    break;

                case GameMessage.SELECT_GAME_TYPE:
                    handleSelectGameType(message);
                    break;

                case GameMessage.PLAY_CARD:
                    handlePlayCard(message);
                    break;

                case GameMessage.CHAT_MESSAGE:
                    // Broadcast chat to session
                    server.broadcastToAll(message);
                    break;

                case GameMessage.REQUEST_SESSIONS:
                    sendSessionList();
                    break;

                default:
                    System.out.println("Unknown message type: " + message.getType());
            }
        } catch (Exception e) {
            System.err.println("Error handling message: " + e.getMessage());
            sendMessage(new GameMessage("ERROR", "SERVER", "Action failed: " + e.getMessage()));
        }
    }

    private void handlePlayerJoin(GameMessage message) {
        this.playerName = (String) message.getData();
        System.out.println("👤 Player identified: " + playerName + " (Client: " + clientId + ")");

        sendMessage(new GameMessage(
                GameMessage.PLAYER_JOINED,
                "SERVER",
                "Welcome " + playerName + "! You are connected to the game server."
        ));
    }

    private void handleJoinSession(GameMessage message) {
        if (!(message.getData() instanceof Integer)) return;

        int sessionId = (Integer) message.getData();
        boolean success = server.joinGameSession(sessionId, playerName, clientId);

        if (success) {
            sendMessage(new GameMessage(
                    GameMessage.JOIN_SUCCESS,
                    "SERVER",
                    sessionId
            ));
        } else {
            sendMessage(new GameMessage(
                    GameMessage.ERROR,
                    "SERVER",
                    "Failed to join session " + sessionId
            ));
        }
    }

    private void handleCreateSession(GameMessage message) {
        // This would need to handle session creation data
        // For now, create a simple session
        // In real implementation, you'd pass player list, etc.
        List<user.Player> players = java.util.Arrays.asList(
                new user.Player(playerName, playerName + "@game.com", "pass")
        );

        // Convert List<Player> to List<String> for player names
        List<String> playerNames = new ArrayList<>();
        List<Boolean> isAI = new ArrayList<>();

        for (Player player : players) {
            playerNames.add(player.getName());
            isAI.add(false); // Default to human players for client-created sessions
        }

        int sessionId = server.createGameSession(playerName, playerNames);

        if (sessionId > 0) {
            // Auto-join the creator to the session
            server.joinGameSession(sessionId, playerName, clientId);

            sendMessage(new GameMessage(
                    GameMessage.SESSION_CREATED,
                    "SERVER",
                    sessionId
            ));
        } else {
            sendMessage(new GameMessage(
                    GameMessage.ERROR,
                    "SERVER",
                    "Failed to create session"
            ));
        }
    }

    private void handleStartGame(GameMessage message) {
        if (!(message.getData() instanceof Integer)) return;

        int sessionId = (Integer) message.getData();
        boolean success = server.startGame(sessionId, playerName);

        if (!success) {
            sendMessage(new GameMessage(
                    GameMessage.ERROR,
                    "SERVER",
                    "Failed to start game in session " + sessionId
            ));
        }
    }

    private void handleSelectGameType(GameMessage message) {
        if (!(message.getData() instanceof GameServer.GameTypeData)) return;

        GameServer.GameTypeData data = (GameServer.GameTypeData) message.getData();
        boolean success = server.selectGameType(data.sessionId, playerName, data.gameType);

        if (!success) {
            sendMessage(new GameMessage(
                    GameMessage.ERROR,
                    "SERVER",
                    "Failed to select game type for session " + data.sessionId
            ));
        }
    }

    private void handlePlayCard(GameMessage message) {
        if (!(message.getData() instanceof GameServer.CardPlayData)) return;

        GameServer.CardPlayData data = (GameServer.CardPlayData) message.getData();
        boolean success = server.playCard(data.sessionId, playerName, data.card);

        if (!success) {
            sendMessage(new GameMessage(
                    GameMessage.ERROR,
                    "SERVER",
                    "Failed to play card in session " + data.sessionId
            ));
        }
    }

    private void sendSessionList() {
        List<data_base_connection.GameSessionInfo> sessions = server.getActiveSessions();
        sendMessage(new GameMessage(
                GameMessage.SESSION_LIST,
                "SERVER",
                sessions
        ));
    }

    public void sendMessage(GameMessage message) {
        if (connected && output != null) {
            try {
                output.writeObject(message);
                output.flush();
                output.reset(); // Reset for same object references
            } catch (IOException e) {
                System.err.println("Failed to send message to client " + clientId);
                disconnect();
            }
        }
    }

    public void disconnect() {
        connected = false;
        try {
            if (output != null) output.close();
            if (input != null) input.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            // Ignore during disconnect
        } finally {
            server.removeClient(clientId);
        }
    }

    // Getters
    public boolean isConnected() { return connected; }
    public String getClientId() { return clientId; }
    public String getPlayerName() { return playerName; }
}